package com.alohaclass.test.DAO;


import com.alohaclass.jdbc.dao.BaseDAOImpl;
import com.alohaclass.test.DTO.Board;

public class BoardDAO extends BaseDAOImpl<Board> {

	

}
