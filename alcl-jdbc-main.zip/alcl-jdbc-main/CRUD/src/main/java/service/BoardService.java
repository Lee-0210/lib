package service;

import dto.Board;

public interface BoardService extends BaseService<Board> {

}
