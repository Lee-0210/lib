package dao;


import com.alohaclass.jdbc.dao.BaseDAOImpl;

import dto.Board;

public class BoardDAO extends BaseDAOImpl<Board> {

}
